package com.example.ghidiembai.viewmodels;

public class PointViewModel {
}
